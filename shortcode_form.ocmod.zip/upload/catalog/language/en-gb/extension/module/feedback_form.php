<?php
$_['heading_title'] = 'Shortcode of feedback form';
//Text
$_['placeholder_name']     = 'Name';
$_['placeholder_email']    = 'Email';
$_['placeholder_phone']    = 'Phone';
$_['text_success']    = 'Message send successfully';

//Entries
$_['entry_name']     = 'Name';
$_['entry_email']    = 'Email';
$_['entry_phone']    = 'Phone';
$_['entry_submit']   = 'Submit';

$_['error_permission'] = 'Warning: You do not have permission to modify module!';
$_['empty_name'] = 'Name must be more than 3 characters';
$_['email_error'] = 'Email incorrect';
$_['phone_error'] = 'Phone incorrect';