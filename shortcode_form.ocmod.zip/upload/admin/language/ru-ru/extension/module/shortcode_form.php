<?php
$_['heading_title'] = 'Шорткод формы обратной связи';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';

//Entries
$_['entry_mask']       = 'Маска шорткода';
$_['entry_status']     = 'Статус';

//Errors
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';
$_['error_mask'] = 'Маска должна иметь вид {# your_shortcode #}';


