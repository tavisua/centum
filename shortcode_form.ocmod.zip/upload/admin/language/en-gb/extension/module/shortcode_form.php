<?php
$_['heading_title'] = 'Shortcode of feedback form';

// Text
$_['text_extension']   = 'Extension';
$_['text_success']     = 'Setting successfully saved!';
$_['text_edit']        = 'Setting';

$_['entry_mask']       = 'Shortcode mask';
$_['entry_status']     = 'Status';

$_['error_permission'] = 'Warning: You do not have permission to modify module!';
$_['error_mask'] = 'The mask should look like {# your_shortcode #}';